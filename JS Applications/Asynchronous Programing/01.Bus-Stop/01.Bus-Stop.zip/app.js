function getInfo() {
    document.getElementById('buses').innerHTML = ''
    let stopID = document.getElementById('stopId').value;

    fetch(`http://localhost:3030/jsonstore/bus/businfo/${stopID}`).then((response) => {
        return response.json()
    }).then((data) => {
        if (!data.name) {
            document.getElementById('stopName').textContent = 'Error'

        } else {
            document.getElementById('stopName').textContent = data.name

        }
        let busesObj = data.buses
        for (let k in busesObj) {
            let li = document.createElement('li');
            document.getElementById('buses').appendChild(li);
            li.textContent = `Bus ${k} arrives in ${busesObj[k]} minutes`;
        }
    }).catch((error) => {
        document.getElementById('stopName').textContent = 'Error'

    })

}