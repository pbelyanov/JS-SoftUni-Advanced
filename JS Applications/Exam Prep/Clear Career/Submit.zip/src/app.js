import {
    homePage
} from "./homePage.js";
import {
    navBar
} from "./navBar.js";

navBar();
homePage();