import {
    createHomePage
} from "./views/homePage.js";

export function homePage(event) {
    createHomePage()
}