import {
    nav
} from "./actions/nav.js";
import {
    dashboardView
} from "./views/dashboardView.js";

nav();
dashboardView();