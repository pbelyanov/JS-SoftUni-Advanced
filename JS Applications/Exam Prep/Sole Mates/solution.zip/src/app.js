import {
    navBar
} from "./nav.js";

import {
    homePage
} from "./views/homeView.js"

navBar()
homePage()